import { BrowserRouter, Routes, Route } from "react-router-dom";

import Navbar from "./components/Navbar";
import Footer from "./components/Footer";

import HomePage from "./pages/home/page";
import OurStory from "./pages/about/OurStory";

export default function App() {
  return (
    <BrowserRouter>
      <Navbar />

      {/* PAGE CONTENT */}
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/about/our-story" element={<OurStory />} />
      </Routes>

      <Footer />
    </BrowserRouter>
  );
}
