export default function OurStoryHero() {
  return (
    <section
      className="relative h-[90vh] flex items-center"
      style={{
        backgroundImage: "url('/images/oss-story-hero.jpg')",
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      {/* Dark Overlay */}
      <div className="absolute inset-0 bg-black/55"></div>

      {/* Content */}
      <div className="relative z-10 mx-auto max-w-[1400px] px-10">
        <div className="max-w-3xl text-white">

          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
            The OSS Story: From Storage <br />
            to Strategic Logistics <br />
            Partnership.
          </h1>

          <p className="mt-6 text-gray-200 text-lg">
            Your One-Stop Solution for Industrial Needs
          </p>

          <div className="mt-10">
            <button
              className="inline-flex items-center gap-2 
                         border border-white px-6 py-3 
                         text-white rounded-md
                         hover:bg-red-600 hover:border-red-600 
                         transition"
            >
              Discover Our Journey
              <span>→</span>
            </button>
          </div>

        </div>
      </div>
    </section>
  );
}
