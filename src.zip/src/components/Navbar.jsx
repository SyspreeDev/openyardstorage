import { Link } from "react-router-dom";
import { useState } from "react";

export default function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <header className="absolute top-0 left-0 z-30 w-full">
      <div className="relative mx-auto flex max-w-[1400px] items-center px-6 py-4 text-white">

        {/* Logo */}
        <div>
          <img
            src="/images/logo.png"
            alt="OSS Logistics"
            className="h-16 w-auto"
          />
        </div>

        {/* Desktop Menu */}
        <nav className="mx-auto hidden md:flex items-center gap-10 text-[15px] font-medium">

          <Link to="/">Home</Link>

          {/* ABOUT DROPDOWN */}
          <div className="relative group">
            <button className="flex items-center gap-1">
              About us <span className="text-xs">▾</span>
            </button>

            <div
              className="absolute left-0 top-full mt-3 w-64 bg-white text-gray-800
                         rounded-lg shadow-lg opacity-0 invisible
                         group-hover:opacity-100 group-hover:visible transition"
            >
              <Link
                to="/about/our-story"
                className="block px-5 py-3 hover:bg-gray-100"
              >
                Our Story
              </Link>

              <span className="block px-5 py-3 text-gray-400 cursor-not-allowed">
                Founders
              </span>
              <span className="block px-5 py-3 text-gray-400 cursor-not-allowed">
                Vision / Mission / Values
              </span>
              <span className="block px-5 py-3 text-gray-400 cursor-not-allowed">
                Inspiration Behind the Company
              </span>
            </div>
          </div>

          <Link to="/services">Services</Link>
          <Link to="/projects">Projects</Link>
          <Link to="/news">News</Link>
          <Link to="/contact">Contact</Link>
        </nav>
      </div>
    </header>
  );
}
