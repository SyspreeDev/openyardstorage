export const blogs = [
  {
    id: 1,
    title: "Oil demand likely to peak in 2030, Predicts UAE expert",
    image: "/blogs/blog1.jpg",
    date: "2024-03-10",
    slug: "oil-demand-peak-2030",
  },
  {
    id: 2,
    title: "Customs Clearance Documentation Process",
    image: "/blogs/blog2.jpg",
    date: "2024-03-10",
    slug: "customs-clearance-documentation",
  },
  {
    id: 3,
    title: "How much Oil and Gas has been found in 2020?",
    image: "/blogs/blog3.jpg",
    date: "2024-03-10",
    slug: "oil-gas-found-2020",
  },
];
